/*
 * File: app/view/user/Edit.js
 */

Ext.define('AM.view.user.Edit', {
    
	extend: 'Ext.window.Window',
    alias : 'widget.useredit',
    title : '������������� �������������',
    layout: 'fit',
    autoShow: true,

    initComponent: function() {
        this.items = [
            {
                xtype: 'form',
                items: [
                    {
                        xtype: 'textfield',
                        name : 'name',
                        fieldLabel: '���',
						style: {'margin' : '10px'},
                    },
                    {
                        xtype: 'textfield',
                        name : 'email',
                        fieldLabel: 'Email',
						style: {'margin' : '10px'},
                    }
                ]
            }
        ];

        this.buttons = [
            {
                text: '���������',
                action: 'save'
            },
            {
                text: '��������',
                scope: this,
                handler: this.close
            }
        ];

        this.callParent(arguments);
    }
});