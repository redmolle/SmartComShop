/*
 * File: app/model/User.js
 */
 
Ext.define('AM.model.User', {
    extend: 'Ext.data.Model',
    fields: ['name', 'email'],
});