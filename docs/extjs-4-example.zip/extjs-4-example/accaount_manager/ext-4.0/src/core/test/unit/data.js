/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

Commercial Usage
Licensees holding valid commercial licenses may use this file in accordance with the Commercial Software License Agreement provided with the Software or, alternatively, in accordance with the terms contained in a written agreement between you and Sencha.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/
/* DO NO EDIT THIS FILE MANUALLY IT IS GENERATED AUTOMATICALLY BY ../build/build.sh */
 this.ExtSpecs = ['spec/class/Class.js','spec/class/ClassManager.js','spec/Date.js','spec/dom/Element.insertion.js','spec/dom/Element.js','spec/dom/Element.static.js','spec/dom/Element.traversal.js','spec/EventManager.js','spec/Ext-more.js','spec/Ext.js','spec/lang/Array.js','spec/lang/Error.js','spec/lang/Function.js','spec/lang/Number.js','spec/lang/Object.js','spec/lang/String.js','spec/misc/JSON.js','spec/Support.js','spec/util/Format.js','spec/version/Version.js'];

