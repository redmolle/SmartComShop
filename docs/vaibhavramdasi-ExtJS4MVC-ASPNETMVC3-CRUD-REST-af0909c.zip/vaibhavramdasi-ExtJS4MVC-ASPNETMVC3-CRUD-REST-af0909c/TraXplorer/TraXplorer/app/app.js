﻿

Ext.Loader.setConfig({ enabled: true });

Ext.application({
    name: 'Traxplorer',
    path: 'app',
    autoCreateViewport: true,
    controllers: ['AlbumsController'],
    launch: function ()
    { 
    
    //Manage Application
    
    }
});